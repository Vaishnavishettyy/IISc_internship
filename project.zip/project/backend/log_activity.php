<?php
require_once "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$username = $data['username'];
$activity = $data['activity'];

$stmt = $db->prepare("INSERT INTO activity (username, activity) VALUES (?, ?)");
$stmt->execute([$username, $activity]);

echo json_encode(["success" => true]);
?>
