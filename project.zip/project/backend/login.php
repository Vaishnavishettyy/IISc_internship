<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "db.php";

$json = file_get_contents("php://input");
$data = json_decode($json, true);

if (!isset($data['username'], $data['password'])) {
    echo json_encode(["success" => false, "message" => "Missing credentials"]);
    exit;
}

$username = $data['username'];
$password = $data['password'];

$stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    echo json_encode(["success" => true, "message" => "Login successful", "username" => $username]);
} else {
    echo json_encode(["success" => false, "message" => "Invalid username or password"]);
}
?>
