<?php
$db = new PDO("sqlite:" . __DIR__ . "/../users.db");

$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT,
    password TEXT
)");

$db->exec("CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    activity TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)");
?>
