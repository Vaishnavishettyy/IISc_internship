document.addEventListener("DOMContentLoaded", function () {
  const signupForm = document.getElementById("signupForm");
  const loginForm = document.getElementById("loginForm");

  // SIGNUP FORM HANDLER
  if (signupForm) {
    const signupBtn = document.getElementById("signupBtn");

    signupForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      signupBtn.disabled = true;
      signupBtn.innerText = "Registering...";

      const signupMessage = document.getElementById("signupMessage");
      if (signupMessage) signupMessage.textContent = "";

      const username = document.getElementById("signupUsername").value.trim();
      const email = document.getElementById("signupEmail").value.trim();
      const password = document.getElementById("signupPassword").value;

      console.log("REGISTER PAYLOAD:", { username, email, password });

      try {
        const res = await fetch("backend/register.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, email, password }),
        });

        const result = await res.json();
        console.log("REGISTER RESPONSE:", result);

        if (signupMessage) signupMessage.textContent = result.message;

        if (result.success) {
          logUserActivity("User registered", { type: "account" }); // ✅ Log registration
          alert("Registration successful!");
          window.location.href = "login.html";
        } else {
          signupBtn.disabled = false;
          signupBtn.innerText = "Sign Up";
        }
      } catch (error) {
        console.error("Signup error:", error);
        if (signupMessage) signupMessage.textContent = "An error occurred. Try again.";
        signupBtn.disabled = false;
        signupBtn.innerText = "Sign Up";
      }
    });
  }

  // LOGIN FORM HANDLER
  if (loginForm) {
    const loginBtn = document.getElementById("loginBtn");

    loginForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      loginBtn.disabled = true;
      loginBtn.innerText = "Logging in...";

      const loginMessage = document.getElementById("loginMessage");
      if (loginMessage) loginMessage.textContent = "";

      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;

      try {
        const res = await fetch("backend/login.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password }),
        });

        const result = await res.json();
        console.log("LOGIN RESPONSE:", result);

        if (loginMessage) loginMessage.textContent = result.message;

        if (result.success) {
          localStorage.setItem("username", result.username);
          logUserActivity("User logged in", { type: "account" }); // ✅ Log login
          alert("Login successful!");
          window.location.href = "main.html";
        } else {
          loginBtn.disabled = false;
          loginBtn.innerText = "Login";
        }
      } catch (error) {
        console.error("Login error:", error);
        if (loginMessage) loginMessage.textContent = "An error occurred. Try again.";
        loginBtn.disabled = false;
        loginBtn.innerText = "Login";
      }
    });
  }

  // MAIN PAGE ACCESS CHECK
  if (window.location.pathname.includes("main.html")) {
    const username = localStorage.getItem("username");
    if (!username) {
      alert("You must be logged in to access this page.");
      window.location.href = "login.html";
    } else {
      logUserActivity("Visited main dashboard"); // ✅ Log main page access
    }
  }
});

// GLOBAL LOGOUT FUNCTION
function logout() {
  localStorage.removeItem("username");
  alert("You have been logged out.");
  window.location.href = "login.html";
}

// GLOBAL ACTIVITY LOGGER
function logUserActivity(activity, options = {}) {
  const username = localStorage.getItem("username");
  if (!username) return;

  const payload = {
    username,
    activity,
    type: options.type || "",
    graph: options.graph || "",
    species: options.species || "",
    mixtureDetails: options.mixtureDetails || null,
  };

  fetch("backend/log_activity.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  }).catch((err) => console.error("Activity log failed:", err));
}
